#!/usr/bin/env bash

GH_PAT=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
GH_BACKUP_USER=lirentian0215
GH_REPO=nezha_backup

error() { echo -e "\033[31m\033[01m$*\033[0m" && exit 1; } # 红色
info() { echo -e "\033[32m\033[01m$*\033[0m"; }   # 绿色
hint() { echo -e "\033[33m\033[01m$*\033[0m"; }   # 黄色

if [ "$1" = a ]; then
  ONLINE="$(wget -qO- --header="Authorization: token $GH_PAT" "https://raw.githubusercontent.com/$GH_BACKUP_USER/$GH_REPO/main/README.md" | sed "/^$/d" | head -n 1)"
  [ "$ONLINE" = "$(cat /dbfile)" ] && exit
  [[ "$ONLINE" =~ tar\.gz$ && "$ONLINE" != "$(cat /dbfile)" ]] && FILE="$ONLINE" && echo "$FILE" > /dbfile || exit
elif [[ "$1" =~ tar\.gz$ ]]; then
  FILE="$1"
fi

until [[ -n "$FILE" || "$i" = 5 ]]; do
  [ -z "$FILE" ] && read -rp ' Please input the backup file name (*.tar.gz): ' FILE
  ((i++)) || true
done

if [ -n "$FILE" ]; then
  [[ "$FILE" =~ http.*/.*tar.gz ]] && FILE=$(awk -F '/' '{print $NF}' <<< $FILE)
else
  error "\n The input has failed more than 5 times and the script exits. \n"
fi

DOWNLOAD_URL=https://raw.githubusercontent.com/$GH_BACKUP_USER/$GH_REPO/main/$FILE
wget --header="Authorization: token $GH_PAT" --header='Accept: application/vnd.github.v3.raw' -O /tmp/backup.tar.gz "$DOWNLOAD_URL"

if [ -e /tmp/backup.tar.gz ]; then
  hint "\n $(supervisorctl stop nezha) \n"
  tar xzvf /tmp/backup.tar.gz --exclude='dashboard/*.sh' -C /
  rm -f /tmp/backup.tar.gz
  hint "\n $(supervisorctl start nezha) \n"
fi

[[ $(supervisorctl status nezha) =~ RUNNING ]] && info "\n Done! \n" || error "\n Fail! \n"
