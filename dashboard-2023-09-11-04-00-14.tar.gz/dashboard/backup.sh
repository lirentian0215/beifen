#!/usr/bin/env bash

GH_PAT=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
GH_BACKUP_USER=lirentian0215
GH_EMAIL=lirentian0215@gmail.com
GH_REPO=nezha_backup

error() { echo -e "\033[31m\033[01m$*\033[0m" && exit 1; } # 红色
info() { echo -e "\033[32m\033[01m$*\033[0m"; }   # 绿色
hint() { echo -e "\033[33m\033[01m$*\033[0m"; }   # 黄色

[ "$(wget -qO- --header="Authorization: token $GH_PAT" https://api.github.com/repos/$GH_BACKUP_USER/$GH_REPO | grep -oPm1 '(?<="private": ).*(?=,)')" != true ] && error "\n This is not exist nor a private repository and the script exits. \n"

[ -n "$1" ] && WAY=Scheduled || WAY=Manualed

# 克隆现有备份库
cd /tmp
git clone https://$GH_PAT@github.com/$GH_BACKUP_USER/$GH_REPO.git --depth 1

# 停掉面板才能备份
hint "\n $(supervisorctl stop nezha) \n"
sleep 3

# github 备份并重启面板
if [[ $(supervisorctl status nezha) =~ STOPPED ]]; then
  TIME=$(date "+%Y-%m-%d-%H:%M:%S")
  tar czvf $GH_REPO/dashboard-$TIME.tar.gz /dashboard
  hint "\n $(supervisorctl start nezha) \n"
  cd $GH_REPO
  [ -e ./.git/index.lock ] && rm -f ./.git/index.lock
  echo "dashboard-$TIME.tar.gz" > /dbfile
  echo "dashboard-$TIME.tar.gz" > README.md
  find ./ -name '*.gz' | sort | head -n -5 | xargs rm -f
  git config --global user.email $GH_EMAIL
  git config --global user.name $GH_BACKUP_USER
  git checkout --orphan tmp_work
  git add .
  git commit -m "$WAY at $TIME ."
  git push -f -u  origin  HEAD:main
  cd ..
  rm -rf $GH_REPO
fi

[[ $(supervisorctl status nezha) =~ RUNNING ]] && info "\n Done! \n" || error "\n Fail! \n"
